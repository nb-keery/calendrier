<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" /> 
		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
				<link rel="shortcut icon" href="images/logo.png" type="image/x-icon" />
				<title><?php echo $titre_page ; ?></title>
			<link rel="stylesheet" type="text/css" href="css/immo.css">
	</head>


<body>
			
			<header>
					<div id="tete">
						<img src="images/logo2.png" width="95" height="95" id="logo">
						<img src="images/titre.png" id="titre">
					</div>
					<?php include("include/nav.php"); ?>
			</header>

			<section>
				<img src="images/projet.jpg" width="980" height="325">
