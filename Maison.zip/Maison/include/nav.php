	<?php	$url = $_SERVER['REQUEST_URI'];
			$page = explode("/", $url);
			$nav = end($page); ?>
				<nav>
					<ul>
						<li class="<?php 
 							if ($nav == 'index.php') {
							echo "actif";
							 }
							else {
							echo " "; } ?>"><a href="index.php">Accueil</a></li>
						<li class="<?php 
							if ($nav == 'annonces.php') {
							echo "actif";
							}
							else {
							echo " "; } ?>"><a href="annonces.php">Acheter</a></li>
						<li class="<?php 
							if ($nav == 'louer.php') {
							echo "actif";
							}
							else {
							echo " "; } ?>"><a href="louer.php">Louer</a></li>
						<li class="<?php 
							 if ($nav == 'contact.php') {
							echo "actif";
							}
							else {
							echo " "; } ?>"><a href="contact.php">Contact</a></li>
					</ul>
				</nav>